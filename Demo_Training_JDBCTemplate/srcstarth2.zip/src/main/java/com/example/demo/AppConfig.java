package com.example.demo;
import org.h2.server.web.WebServlet;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.example.config.CustomerConfig;
import com.example.config.EmployeeConfig;
import com.example.config.InvoiceConfig;

@EnableAutoConfiguration
@Configuration
@Import({EmployeeConfig.class,CustomerConfig.class,InvoiceConfig.class})
public class AppConfig 
{
	//Custom config can be declared here
	//it helps to look up the h2 database on browser
	@Bean
	   ServletRegistrationBean h2servletRegistration(){
	   ServletRegistrationBean registrationBean = new  ServletRegistrationBean( new WebServlet());
	    registrationBean.addUrlMappings("/console/*");
	     return registrationBean;
	    }

}
